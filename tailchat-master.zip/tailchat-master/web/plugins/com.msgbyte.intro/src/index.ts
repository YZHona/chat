/**
 * 异步加载
 */
import('./tour');
