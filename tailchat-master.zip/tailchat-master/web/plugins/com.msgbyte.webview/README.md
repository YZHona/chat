## com.msgbyte.webview

为 `Tailchat` 增加 `Webview` 能力

### Usage

在 群组设置 -> 创建面板 可以添加网页面板。
