## com.msgbyte.snapdrop

为 `Tailchat` 增加 局域网文件互传的功能

Powered by [snapdrop](https://github.com/RobinLinus/snapdrop.git)

### 使用方式

仅需要在同一网络下两个设备均打开 [我 -> 隔空投送] 面板，单击或长按即可发送
