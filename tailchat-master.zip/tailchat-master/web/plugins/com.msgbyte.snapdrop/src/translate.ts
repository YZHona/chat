import { localTrans } from '@capital/common';

export const Translate = {
  panelName: localTrans({ 'zh-CN': '隔空投送', 'en-US': 'Snapdrop' }),
};
