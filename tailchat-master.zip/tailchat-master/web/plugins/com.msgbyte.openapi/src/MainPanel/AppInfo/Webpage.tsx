import React from 'react';

const Webpage: React.FC = React.memo(() => {
  return <div>开发中</div>;
});
Webpage.displayName = 'Webpage';

export default Webpage;
