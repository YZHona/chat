import { BBCode } from './bbcode';
import './tags/__all__';

export default BBCode;
