declare module '@bbob/parser';
