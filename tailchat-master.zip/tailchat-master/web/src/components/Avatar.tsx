export {
  /**
   * @deprecated please import it from tailchat-design
   */
  Avatar,
} from 'tailchat-design';
