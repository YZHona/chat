Fork from https://github.com/mattermost/dynamic-virtualized-list
