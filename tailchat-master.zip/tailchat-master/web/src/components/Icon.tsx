export { Icon } from 'tailchat-design';
