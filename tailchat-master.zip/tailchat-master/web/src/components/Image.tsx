export { Image } from 'tailchat-design';
