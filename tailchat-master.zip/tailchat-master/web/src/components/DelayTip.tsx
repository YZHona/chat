export { DelayTip } from 'tailchat-design';
