module.exports = require('../web/tailwind.config');
