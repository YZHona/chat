export const t = (key: string) => {
  return key;
};

export function onLanguageChange() {}
