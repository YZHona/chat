## Portal

**暂时没有使用**

这是一组用于使用命令式方法将一个React DOM映射到相关的位置的方法
可以指定不同的portal位置

用于处理对于每个节点都需要创建一个相关的Modal的情况

> 参考 https://github.com/ant-design/ant-design-mobile-rn/blob/master/components/portal/ 的实现
