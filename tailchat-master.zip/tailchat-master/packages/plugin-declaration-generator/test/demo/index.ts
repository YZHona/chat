export { foo } from '@/foo';
export { bar } from '@/bar';

/**
 * Root export
 */
export function main() {
  console.log('main');
}
