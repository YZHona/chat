/**
 * This is bar
 */
export function bar() {
  console.log('Anything else');
}
