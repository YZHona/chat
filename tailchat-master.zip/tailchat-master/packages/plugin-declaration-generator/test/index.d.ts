declare module '@capital/foo' {
  export const a: any;
  export const b: string;
}
